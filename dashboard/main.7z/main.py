import pandas as pd
import datetime
import os

today = datetime.date.today()
three_days_ago = today - datetime.timedelta(days=3)
week_number = three_days_ago.isocalendar()[1]
path = os.getcwd()
for file in os.listdir(path):
    if file.endswith(".xlsx"):
        df2=pd.read_excel(file,header=2)
        Week=f"WK'{week_number}"

        df=df2[['lotnumber','Qty IN','qty','qty.27','qty.28','qty.30','qty.31']]
        df_fail=df[(df['qty.27'] != 0) | (df['qty.28'] != 0) | (df['qty.30'] != 0) | (df['qty.31'] != 0)]

        df=df2[['lotnumber','Qty IN','qty','qty.27','qty.28','qty.30','qty.31']]
        df_ok=df[(df['qty.27'] == 0) & (df['qty.28'] == 0) & (df['qty.30'] == 0) & (df['qty.31'] == 0)]
    elif file.endswith(".csv"):
        df=pd.read_csv(file)
        df=df[['lotnumber','part_id','swbin_desc']]
        df.to_excel(f"failed_units {Week}.xlsx",index=False)
Overview_df=pd.DataFrame()
data={'Week':[Week,Week],
     'Lots': ['0 MMP', 'with MMP'],
     'Number Of Lots':[df_ok['lotnumber'].count(),df_fail['lotnumber'].count()],
     'QTY in (Ku)':[df_ok['Qty IN'].sum()/1000,df_fail['Qty IN'].sum()/1000],
     'Good (Ku)':[df_ok['qty'].sum()/1000,df_fail['qty'].sum()/1000],
     'Yield':[round(100*df_ok['qty'].sum()/df_ok['Qty IN'].sum(),2),round(100*df_fail['qty'].sum()/df_fail['Qty IN'].sum(),2)],
     'HTRB_M': [0, df_fail['qty.27'].sum()],
     'FUNC_3': [0, df_fail['qty.28'].sum()],
     'HTGB_HTM': [0, df_fail['qty.30'].sum()],
     'FUNC_4': [0, df_fail['qty.31'].sum()]}
Overview_df = pd.DataFrame(data).set_index('Lots')
Overview_df.to_excel(f"Overview MMP {Week} .xlsx")